
------

Plus d'informations sur Automator sur [Automatisez.net](http://Automatisez.net/)
