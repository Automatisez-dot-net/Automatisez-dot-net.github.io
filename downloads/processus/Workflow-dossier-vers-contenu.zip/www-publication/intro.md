# Construire une page de Contenu

## Objectif

Vous avez un dossier rempli de fichiers audios, de photos ou de vidéos, et vous voulez mettre le tout dans une page internet?

Comment publier le tout dans une page internet? La solution peut-être très simple en utilisant  Automator.

L'idée est de fournir deux fichiers:

1. un fichier d'en-tête qui contient le début de la page (en-tête, introduction).
2. un fichier de conclusion qui contiendra la fin de la page.

La partie intermédiaire, qui contriendra la liste des fichiers sera construire par un processus Automator à partir du contenu du dossier des médias.

## Exemple de contenu

Ce qui suit est généré par le processus.
