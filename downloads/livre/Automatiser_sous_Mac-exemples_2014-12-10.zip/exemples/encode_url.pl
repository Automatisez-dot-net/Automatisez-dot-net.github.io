#!/usr/bin/perl

use strict;
use URI::Escape;

print uri_escape($ARGV[0]);
