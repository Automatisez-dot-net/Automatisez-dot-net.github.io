//
//  main.m
//  SimpleASCocoa
//
//  Created by Gamel Sylvain on 30/01/2012.
//  Copyright (c) 2012 S.G. inTech. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import <AppleScriptObjC/AppleScriptObjC.h>

int main(int argc, char *argv[])
{
    [[NSBundle mainBundle] loadAppleScriptObjectiveCScripts];
    return NSApplicationMain(argc, (const char **)argv);
}
