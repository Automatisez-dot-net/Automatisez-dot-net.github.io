Automator-ActionLock
===============

English
----------

A simple example project to buidl an action that locks and unlocks file and folders.

This basic project uses a simple shell commande to manipulate the lock attribute of files and folders in the same way as the Finder does.

For more information about Automator, you may go to [Automatisez.net](http://Automatisez.net/) French web site.

Français
-----------

Ce projet est un exemple simple de l'implémentation d'une action Automator pour vérrouiller et déverrouiller fichiers et dossiers.

Ce projet utilise une simple commande Shell pour imiter le comportement du Finder lors du verrouillage et déverrouillage.

Pour plus d'informations sur Automator, rendez-vous sur [Automatisez.net](http://Automatisez.net/).