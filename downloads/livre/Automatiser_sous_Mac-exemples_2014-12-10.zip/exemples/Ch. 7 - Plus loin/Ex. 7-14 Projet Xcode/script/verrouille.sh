#!/bin/bash

leFichier=$1
status=$2

# Par défaut, de-verrouille le fichier
flag="nouchange"

if test "L" == "$status"
then
	# Lock the file
	flag="uchange"
fi

chflags $flag $leFichier
