// Variables used by Scriptable.
// These must be at the very top of the file. Do not edit.
// icon-color: cyan; icon-glyph: image;
// API og APOD
let apiURL = "https://api.nasa.gov/planetary/apod";
let apiKey = "DEMO_KEY";
if ( Keychain.contains('nasa-api-key') ) {
  apiKey = Keychain.get('nasa-api-key');
}

// Public URL
let apodNavURL = "https://apod.nasa.gov";

// basic widget creation
function createWidget() {
  let widget = new ListWidget();

  widget.spacing = 0;
  widget.setPadding(0, 0, 0, 0);

  return widget;
}


// access APOD API to get image
// then update widget
async function loadPhoto(widget) {
  let requestURI = `${apiURL}?api_key=${apiKey}`;
  
  let request = new Request(requestURI);
  console.log(`Request: ${requestURI}`);
  let json = await request.loadJSON();
  console.log(`Response: ${JSON.stringify(json)}`);
  
  if ( json && json.url ) {
    let imgRequest = new Request(json.url);
    let img = await imgRequest.loadImage();
  
    widget.backgroundImage = img;
    widget.url = apodNavURL;
  } else if ( json && json.error && json.error.message ) {
    widget.addText(json.error.message);
  } else {
    widget.addText("Erreur. Pas de réponse.")
  }
}


// create widget, load image and push widget
let widget = createWidget();
await loadPhoto(widget);

// check environment to just display widget content
// when running from Scriptable app
if (config.runsInWidget) {
  Script.setWidget(widget);
} else {
  widget.presentSmall();
}

// We must notify caller that script ended
Script.complete();





